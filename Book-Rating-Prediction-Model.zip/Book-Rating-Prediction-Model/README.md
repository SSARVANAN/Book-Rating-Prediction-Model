# Book-Rating-Prediction-Model
This project aims  to build a machine learning model capable of predicting a book’s rating by analyzing various features associated with books, such as title, author, number of pages, publication year, review counts etc.
